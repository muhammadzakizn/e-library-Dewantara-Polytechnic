# E-Library Politeknik Dewantara

Sistem perpustakaan digital berbasis web untuk Politeknik Dewantara. Menyediakan akses ke koleksi buku digital, jurnal ilmiah, modul pembelajaran, dan manajemen laporan magang secara terpusat.

<img width="1470" height="803" alt="Screenshot 2026-02-10 at 1 56 06 PM" src="https://github.com/user-attachments/assets/7e990ed8-a9e3-4aae-b2ed-a5ea71a47e63" />

**URL Produksi:** [https://e-library.muhammadzakizn.com](https://e-library.muhammadzakizn.com)

---

## Daftar Isi

- [Fitur Utama](#fitur-utama)
- [Teknologi](#teknologi)
- [Struktur Proyek](#struktur-proyek)
- [Prasyarat](#prasyarat)
- [Instalasi dan Menjalankan Lokal](#instalasi-dan-menjalankan-lokal)
- [Konfigurasi Environment](#konfigurasi-environment)
- [Migrasi Database](#migrasi-database)
- [Deployment](#deployment)
- [Panduan Penggunaan](#panduan-penggunaan)
- [Kontributor](#kontributor)

---

## Fitur Utama

### Halaman Publik

- **Beranda** - Landing page dengan pencarian koleksi, statistik perpustakaan, dan slideshow.
- **Tentang** - Informasi mengenai perpustakaan dan visi misi.
- **Koleksi** - Katalog buku digital dengan filter berdasarkan kategori, pencarian judul/pengarang, dan paginasi. Terdiri dari sub-halaman: Buku Digital, Jurnal Ilmiah, Modul Ajar, dan Laporan Magang.
- **Panduan** - Dokumentasi cara penggunaan sistem.
- **Kontak** - Formulir dan informasi kontak perpustakaan.

### Autentikasi

- **Login Mahasiswa** - Autentikasi menggunakan email dan password via Supabase Auth. Mendukung registrasi akun baru dengan NIM, nama, dan program studi.
- **Login Admin/Dosen** - Autentikasi terpisah menggunakan email/username dan password.
- **Lupa Password** - Reset password melalui tautan yang dikirim ke email.
- **Pembaruan Password** - Halaman untuk mengatur password baru dari tautan reset.
- **OAuth Integration** - Mendukung login menggunakan akun Google.

### Dashboard Mahasiswa

- **Beranda Dashboard** - Menampilkan statistik membaca (buku dibaca, jam membaca, favorit, streak), riwayat baca terakhir, dan quick actions.
- **Reader Buku** - Pembaca buku digital di browser, mendukung format EPUB dan PDF dengan navigasi halaman dan pengaturan tampilan.
- **Koleksi Saya** - Manajemen koleksi buku pribadi yang disimpan oleh mahasiswa.
- **Favorit** - Daftar buku yang ditandai sebagai favorit.
- **Riwayat Baca** - Catatan histori buku yang pernah dibaca.
- **Upload Laporan Magang** - Formulir untuk mengunggah laporan magang beserta metadata.
- **Laporan Saya** - Melihat status dan riwayat laporan yang telah diunggah.
- **Pengaturan Profil** - Mengedit informasi profil, foto profil (dengan fitur crop), menghubungkan akun Google, dan mengubah password. Halaman ini khusus untuk mahasiswa.

### Panel Admin

Diakses melalui `/admin/dashboard`. Admin dan dosen yang masuk akan otomatis diarahkan ke panel ini.

- **Dashboard Beranda** - Ringkasan statistik: jumlah pengguna, admin, laporan, dan laporan pending.
- **Kelola Jurusan (Program Studi)** - Tambah, edit, dan hapus program studi. Khusus admin.
- **Kelola Akun Admin/Dosen** - Membuat akun admin/dosen baru, mengedit profil, menghapus akun, dan mengubah password. Khusus admin.
- **Kelola Mahasiswa** - Melihat daftar seluruh mahasiswa dengan pencarian berdasarkan nama, email, atau NIM. Fitur meliputi:
  - Edit profil mahasiswa (nama, NIM, program studi)
  - Reset password melalui email
  - Batasi akses (ban) dengan alasan, dan pulihkan akses (unban)
- **Modul Ajar** - Upload dan kelola modul ajar per jurusan. Tersedia untuk admin dan dosen. Fitur meliputi:
  - Upload modul dengan judul, deskripsi, mata kuliah, semester, tahun ajaran, dan jurusan
  - Upload foto cover dan file dokumen (PDF/DOC/PPT) ke Supabase Storage
  - Dosen hanya melihat modul dari jurusannya sendiri, admin melihat seluruh modul
  - Filter berdasarkan jurusan dan pencarian berdasarkan judul/dosen/mata kuliah
  - Edit, hapus, dan download modul
  - Status modul: Dipublikasi, Draf, atau Diarsipkan
- **Laporan Magang** - Melihat, menyetujui, atau menolak laporan magang dari mahasiswa. Dosen hanya melihat laporan dari jurusannya.
- **Pengaturan Sistem** - Mengatur parameter sistem seperti jumlah buku per halaman, batas hasil API, dan izin upload publik. Termasuk:
  - Toggle mode maintenance
  - Pesan maintenance yang dapat dikustomisasi

### Sistem Keamanan

- **Maintenance Mode** - Overlay penuh ditampilkan kepada mahasiswa saat sistem dalam pemeliharaan. Memeriksa status setiap 30 detik. Admin/dosen tidak terpengaruh. Banner peringatan juga ditampilkan di halaman login.
- **Ban System** - Overlay penuh ditampilkan kepada mahasiswa yang aksesnya dibatasi, menampilkan alasan pembatasan dan kontak admin. Memeriksa status setiap 60 detik.
- **Role-Based Access Control** - Admin/dosen yang mengakses `/dashboard` otomatis diarahkan ke `/admin/dashboard`. Halaman pengaturan mahasiswa tidak dapat diakses oleh admin/dosen. Menu navigasi menyesuaikan berdasarkan role pengguna.

### Fitur Tambahan

- **Dark Mode** - Mendukung tema gelap yang dapat diaktifkan oleh pengguna.
- **Responsive Design** - Tampilan menyesuaikan untuk desktop dan perangkat mobile.
- **Halaman 404** - Halaman kustom untuk URL yang tidak ditemukan.
- **SEO** - Meta title dan description pada setiap halaman.

---

## Teknologi

| Komponen         | Teknologi                 |
|------------------|---------------------------|
| Framework        | Next.js 14 (App Router)   |
| Bahasa           | TypeScript                |
| Styling          | Tailwind CSS 3            |
| Backend / Auth   | Supabase (PostgreSQL, Auth, Storage) |
| Ikon             | Lucide React              |
| Reader EPUB      | epub.js                   |
| Reader PDF       | pdf.js                    |
| Image Crop       | react-easy-crop           |
| Utility CSS      | clsx, tailwind-merge      |
| State Management | React Hooks, Server Actions |
| Deployment       | Vercel                    |
| Domain           | Cloudflare DNS            |

---

## Struktur Proyek

```
src/
  app/
    page.tsx                  # Halaman beranda
    login/                    # Halaman login & registrasi
    lupa-password/            # Reset password
    update-password/          # Formulir password baru
    dashboard/                # Dashboard mahasiswa
      page.tsx                # Beranda dashboard
      koleksi/                # Koleksi pribadi
      favorit/                # Daftar favorit
      riwayat/                # Riwayat baca
      reader/                 # Reader buku (EPUB/PDF)
      unggah-laporan/         # Upload laporan magang
      laporan-saya/           # Status laporan
      pengaturan/             # Pengaturan profil
      profil/                 # Halaman profil
    admin/
      dashboard/page.tsx      # Panel admin
    koleksi/                  # Katalog koleksi publik
      buku-digital/           # Sub-halaman buku digital
      jurnal/                 # Sub-halaman jurnal ilmiah
      modul/                  # Sub-halaman modul ajar
      laporan-magang/         # Sub-halaman laporan magang
    tentang/                  # Halaman tentang
    panduan/                  # Halaman panduan
    kontak/                   # Halaman kontak
    daftar/                   # Halaman registrasi
  components/
    layout/
      Header.tsx              # Navigasi utama
      Footer.tsx              # Footer
    MaintenanceGuard.tsx      # Overlay maintenance mode
    BanGuard.tsx              # Overlay akun dibatasi
    ui/                       # Komponen UI reusable
  lib/
    supabase/
      client.ts               # Supabase client (browser)
      server.ts               # Supabase client (server)
      middleware.ts            # Middleware autentikasi
      migrations/              # File migrasi SQL
```

---

## Prasyarat

- Node.js versi 18 atau lebih baru
- npm atau yarn
- Akun Supabase (gratis di [supabase.com](https://supabase.com))
- Git

---

## Instalasi dan Menjalankan Lokal

1. Clone repository:

```bash
git clone https://github.com/muhammadzakizn/e-library-Dewantara-Polytechnic.git
cd e-library-Dewantara-Polytechnic
```

2. Install dependencies:

```bash
npm install
```

3. Buat file `.env.local` di root proyek (lihat bagian [Konfigurasi Environment](#konfigurasi-environment)).

4. Jalankan server development:

```bash
npm run dev
```

5. Buka browser dan akses `http://localhost:3000`.

### Build Produksi

```bash
npm run build
npm run start
```

---

## Konfigurasi Environment

Buat file `.env.local` di root proyek dengan isi berikut:

```env
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
```

Nilai ini didapatkan dari Supabase Dashboard pada bagian Settings > API.

---

## Migrasi Database

Jalankan file migrasi SQL secara berurutan di Supabase Dashboard (SQL Editor):

1. `src/lib/supabase/migrations/20240101_collections.sql` - Tabel koleksi buku dan kategori
2. `src/lib/supabase/migrations/20240210_user_activity.sql` - Statistik aktivitas pengguna
3. `src/lib/supabase/migrations/20240224_admin_roles.sql` - Konfigurasi role dan permission
4. `src/lib/supabase/migrations/20240224_check_user_exists.sql` - Helper autentikasi
5. `src/lib/supabase/migrations/20240225_laporan_magang.sql` - Tabel laporan magang
6. `src/lib/supabase/migrations/20240226_admin_panel.sql` - Tabel jurusan, pengaturan aplikasi, dan profil admin
7. `src/lib/supabase/migrations/20240227_student_mgmt.sql` - Kolom ban system dan maintenance message
8. `src/lib/supabase/migrations/20240228_modul_ajar.sql` - Tabel modul ajar dengan RLS

Setiap file migrasi bersifat idempotent (menggunakan `IF NOT EXISTS`), sehingga aman untuk dijalankan ulang.

### Supabase Storage

Buat storage bucket `modul-ajar` di Supabase Dashboard (Storage) dengan akses public untuk menyimpan file modul dan cover.

---

## Deployment

### Deploy ke Vercel

1. Login ke [vercel.com](https://vercel.com) dan import repository GitHub.
2. Pada konfigurasi project, tambahkan environment variables:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
3. Framework Preset akan otomatis terdeteksi sebagai Next.js.
4. Klik **Deploy**.

### Konfigurasi Domain via Cloudflare

1. Di Vercel, buka Settings > Domains, tambahkan `e-library.muhammadzakizn.com`.
2. Di Cloudflare DNS untuk domain `muhammadzakizn.com`, tambahkan record:
   - Tipe: `CNAME`
   - Nama: `e-library`
   - Target: `cname.vercel-dns.com`
   - Proxy status: DNS Only (matikan proxy Cloudflare / awan abu-abu)
3. Tunggu propagasi DNS (biasanya beberapa menit).
4. Vercel akan otomatis mengeluarkan sertifikat SSL.

---

## Panduan Penggunaan

### Untuk Mahasiswa

1. Buka halaman login dan pilih tab **Mahasiswa**.
2. Masukkan email. Jika belum terdaftar, akan diarahkan ke formulir registrasi.
3. Setelah login, halaman dashboard menampilkan ringkasan aktivitas membaca.
4. Gunakan menu **Koleksi** untuk menjelajahi dan membaca buku digital.
5. Simpan buku ke koleksi pribadi atau tandai sebagai favorit.
6. Untuk mengunggah laporan magang, gunakan menu **Upload Laporan** di dashboard.
7. Status persetujuan laporan dapat dilihat di menu **Laporan Saya**.
8. Edit profil, foto, dan password melalui menu **Pengaturan**.

### Untuk Admin

1. Buka halaman login dan pilih tab **Admin / Dosen**.
2. Login dengan email/username dan password.
3. Panel admin menampilkan ringkasan statistik di halaman Beranda.
4. Kelola program studi melalui menu **Kelola Jurusan**.
5. Kelola akun admin dan dosen melalui menu **Kelola Akun**.
6. Kelola mahasiswa melalui menu **Kelola Mahasiswa** (edit profil, reset password, batasi akses).
7. Upload dan kelola modul ajar melalui menu **Modul Ajar**.
8. Tinjau dan setujui/tolak laporan magang melalui menu **Laporan Magang**.
9. Atur parameter sistem dan mode maintenance melalui menu **Pengaturan Sistem**.

### Untuk Dosen

1. Proses login sama dengan admin.
2. Akses terbatas pada Beranda, Modul Ajar (hanya jurusan sendiri), Laporan Magang (hanya jurusan sendiri), dan Pengaturan Sistem.
3. Menu Kelola Jurusan dan Kelola Akun tidak tersedia untuk dosen.
4. Dosen dapat meng-upload modul ajar yang otomatis terhubung ke jurusan yang ditugaskan.

---

## Kontributor

Project ini dikembangkan oleh **Kelompok 2** - Semester 5 Politeknik Dewantara.

1. Fildzah Hashilah N
2. Muhammad Zaky Z N
3. Nurheni
4. Fitriany
5. Hardiani
6. Nurul Hikmah
7. Lusiana
8. Ainin
9. Muliani
10. Sazkia
11. Rafia
12. Yusnia
13. Aulia
14. Nurliana
15. Jesika

---
(c) 2024 Politeknik Dewantara. All Rights Reserved.
